
conda create -n car_price python=3.9 -y

conda activate car_price

created a requirements.txt file

pip install -r requirements.txt to loaad libraries

git init

dvc init

dvc add data_given/cardata.csv

git add .

git commit -m "first commit"

git add . && git commit -m "update Readme.md"

git remote add origin https://github.com/Nash242/Car-demo.git
git branch -M main
git push origin main
